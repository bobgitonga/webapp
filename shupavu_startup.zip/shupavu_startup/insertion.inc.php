<?php 

session_start();

//Register User
if (isset($_POST['regu'])) {
 $fname = $_POST['fname'];
 $email = $_POST['email'];
 $phone = $_POST['phone'];
 $type = $_POST['type'];
 $qual = $_POST['qual']; 
 $password = $_POST['password'];
 $passwordconfirm = $_POST['cpassword'];

 require_once 'dbconnection.inc.php';

 if ($password == $passwordconfirm) {
  if (!isset($_SESSION['adminname'])) {
  $sql = "INSERT INTO `users`(`Fullname`, `Phone_Number`, `Email_Address`,`User_Type`, `Password`, `Qualifications`) VALUES ('$fname','$phone','$email','User',md5('$password'),'$qual')";
     mysqli_query($conn, $sql);
  header("Location: index.html?userregistration=success");
  }else{
  $sql = "INSERT INTO `users`(`Fullname`, `Phone_Number`, `Email_Address`, `User_Type`, `Password`) VALUES ('$fname','$phone','$email','$type',md5('$password'))";
     mysqli_query($conn, $sql);
  header("Location: index.php?userregistration=success");
  }
 }else{
  echo "Passwords do not match.";
 }
}

//Add An Application
if (isset($_POST['addA'])) {
 $emp = $_SESSION['menname'];
 $fee = $_POST['fee']; 
 $desc = $_POST['desc']; 
 $end = $_POST['end']; 
 $aname = $_POST['aname']; 

 require_once 'dbconnection.inc.php';               

$filename = $_FILES['image']['name'];

$valid_extensions = array("jpg","jpeg","png");

$extension = pathinfo($filename, PATHINFO_EXTENSION);

if((in_array(strtolower($extension),$valid_extensions))) {

if((move_uploaded_file($_FILES['image']['tmp_name'], "images/".$filename))){

  $sql = "INSERT INTO `applications`(`Mentor_ID`, `Fee`, `Description`, `Name`, `End`, `Image`) VALUES ('$emp','$fee','$desc','$aname','$end','$filename')";
     mysqli_query($conn, $sql);   
  header("Location: index1.php?addapplication=success");
  }else{
  echo "An Error Occured: Image directory not found.";
}
}else{
  echo "An Error Occured: Kindly check the image format, current format is not accepted.";
} 
}

//Add Content
if (isset($_POST['addC'])) {
 $desc = $_POST['desc']; 
 $url = $_POST['url']; 
 $cname = $_POST['cname']; 

 require_once 'dbconnection.inc.php';               

$filename = $_FILES['image']['name'];

$valid_extensions = array("jpg","jpeg","png", "doc", "docx", "pdf");

$extension = pathinfo($filename, PATHINFO_EXTENSION);

if((in_array(strtolower($extension),$valid_extensions))) {

if((move_uploaded_file($_FILES['image']['tmp_name'], "documents/".$filename))){

  $sql = "INSERT INTO `content`(`Description`, `Name`, `Image`, `URL`) VALUES ('$desc','$cname','$filename','$url')";
     mysqli_query($conn, $sql);   
  header("Location: index2.php?addcontent=success");
  }else{
  echo "An Error Occured: File directory not found.";
}
}else{
  echo "An Error Occured: Kindly check the file format, current format is not accepted.";
} 
}

//View A Chat
if($_REQUEST['action'] == 'viewC' && !empty($_REQUEST['id'])){ 
$deleteItem = $_REQUEST['id'];
$_SESSION['chatname'] = $deleteItem;
    header("Location: chat.php");
}

//Add A Chat
if(isset($_POST["addCh"])){

    require_once 'dbconnection.inc.php';

  if (isset($_SESSION['chatname']) && isset($_SESSION['username'])) {
    $uid = $_SESSION['username1'];
  }else{
    $uid = $_SESSION['menname1'];
  }

  $oid = $_SESSION['chatname']; 
  $desc = $_POST['desc'];

   $sql = "INSERT INTO `chat`(`Sender`, `Receiver`, `Message`) VALUES ('$uid','$oid','$desc')";
   mysqli_query($conn, $sql);
header("Location: chat.php?sendmessage=success");
}

//Complete An Application
if (isset($_POST['completeA'])) {
    $uid = $_POST['uid'];
    $did = $_POST['did'];

        require_once 'dbconnection.inc.php';

        $sql = "UPDATE `applications` SET `Status` = 'Completed', `Mentee_ID` = '$uid' WHERE `Application_ID` = '$did'";
        mysqli_query($conn, $sql); 
        header("Location: index1.php?completeapplication=success");

}

//Delete Functions

        if($_REQUEST['action'] == 'deleteU' && !empty($_REQUEST['id'])){ 
        require_once 'dbconnection.inc.php';
        $deleteItem = $_REQUEST['id'];
        $sql = "DELETE FROM `users` WHERE `User_ID` = '$deleteItem'";
        mysqli_query($conn, $sql); 
        header("Location: index.php?deleteuser=success");
        }         

        if($_REQUEST['action'] == 'deleteA' && !empty($_REQUEST['id'])){ 
        require_once 'dbconnection.inc.php';
        $deleteItem = $_REQUEST['id'];
        $sql = "DELETE FROM `applications` WHERE `Application_ID` = '$deleteItem'";
        mysqli_query($conn, $sql); 
        header("Location: index1.php?deleteapplication=success");
        }   

        if($_REQUEST['action'] == 'deactivateA' && !empty($_REQUEST['id'])){ 
        require_once 'dbconnection.inc.php';
        $deleteItem = $_REQUEST['id'];
        $sql = "UPDATE `applications` SET `Status` = 'Deactivated' WHERE `Application_ID` = '$deleteItem'";
        mysqli_query($conn, $sql); 
        header("Location: index1.php?deactivateapplication=success");
        } 

        if($_REQUEST['action'] == 'activateA' && !empty($_REQUEST['id'])){ 
        require_once 'dbconnection.inc.php';
        $updateItem = $_REQUEST['id'];
        $sql = "UPDATE `applications` SET `Status` = 'Active' WHERE `Application_ID` = '$updateItem'";
        mysqli_query($conn, $sql); 
        header("Location: index1.php?activateapplication=success");
        }    

        if($_REQUEST['action'] == 'deleteC' && !empty($_REQUEST['id'])){ 
        require_once 'dbconnection.inc.php';
        $deleteItem = $_REQUEST['id'];
        $sql = "DELETE FROM `content` WHERE `Content_ID` = '$deleteItem'";
        mysqli_query($conn, $sql); 
        header("Location: index2.php?deletecontent=success");
        }   

        if(isset($_POST['deleteCh'])){ 
        require_once 'dbconnection.inc.php';
        $deleteItem = $_POST['cid'];
        $sql = "DELETE FROM `chat` WHERE `Chat_ID` = '$deleteItem'";
        mysqli_query($conn, $sql); 
        header("Location: chat.php?deletemessage=success");
        }         

//Update User
if (isset($_POST['upu'])) {
 $uid = $_POST['uid'];
 $fname = $_POST['fname'];
 $email = $_POST['email'];
 $qual = $_POST['qual']; 
 $password = $_POST['password'];
 $passwordconfirm = $_POST['cpassword'];
 $phone = $_POST['phone'];
 $mod = $_POST['mod'];
 $qual = $_POST['qual'];

 require_once 'dbconnection.inc.php';

 if ($password == $passwordconfirm) {
  if ($mod == 1) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password') WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: index.php?updateadministrator=success");
  }else if ($mod == 2) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password') WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: index1.php?updatementor=success");
  }else if ($mod == 3) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password'), `Qualifications` = '$qual' WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: index2.php?updatecontentprovider=success");
  }else if ($mod == 4) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password'), `Qualifications` = '$qual' WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: index3.php?updateuser=success");
  }
 }else{
  echo "Passwords do not match.";
 }
}

 ?>