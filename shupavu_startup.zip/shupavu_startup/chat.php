<?php
require_once 'dbconnection.inc.php';
session_start();

if (isset($_SESSION['username']) || isset($_SESSION['username1']) || isset($_SESSION['menname']) || isset($_SESSION['menname1']) || isset($_SESSION['chatname'])) {
  if (isset($_SESSION['username'])) {
  $filter = $_SESSION['username'];
  $filter1 = $_SESSION['username1'];
  $filter2 = $_SESSION['chatname'];
}else{
  $filter = $_SESSION['menname'];
  $filter1 = $_SESSION['menname1'];
  $filter2 = $_SESSION['chatname'];
}
  $query=mysqli_query($conn,"SELECT * FROM `users` WHERE `User_ID`='$filter'")or die(mysqli_error());
  $row1=mysqli_fetch_array($query);
    $sql = "UPDATE `chat` SET `Status`='Read' WHERE `Sender`='$filter2' AND `Receiver` = '$filter1'";
  mysqli_query($conn, $sql); 
}    
else{
    header("Location: index.html");
}
?>

<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>Shupavu Startup - Chat Page</title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,600,700&display=swap" rel="stylesheet" />

  <!-- Custom styles -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>
<style type="text/css">
  /* Chat containers */
.Ccontainer {
  border: 2px solid #dedede;
  background-color: #f1f1f1;
  border-radius: 5px;
  padding: 0px;
  margin: 40px 20px;
}

/* Darker chat container */
.darker {
  border-color: #ccc;
  background-color: #ddd;
}

/* Clear floats */
.container::after {
  content: "";
  clear: both;
  display: table;
}

/* Style time text */
.time-right {
  float: right;
  color: #aaa;
}

/* Style time text */
.time-left {
  float: left;
  color: #999;
}
</style>
<body>
  <div class="hero_area">
    <!-- header section strats -->
    <div class="hero_bg_box">
      <div class="img-box">
        <img src="images/hero-bg.jpg" alt="">
      </div>
    </div>

    <header class="header_section">
      <div class="header_top">
        <div class="container-fluid">
          <div class="contact_link-container">
            <a href="" class="contact_link1">
              <i class="fa fa-map-marker" aria-hidden="true"></i>
              <span>
                Location : Nairobi, Kenya,
              </span>
            </a>
            <a href="" class="contact_link2">
              <i class="fa fa-phone" aria-hidden="true"></i>
              <span>
                Call : +254 712345678
              </span>
            </a>
            <a href="" class="contact_link3">
              <i class="fa fa-envelope" aria-hidden="true"></i>
              <span>
                Email Address : info@shupavu.org
              </span>
            </a>
          </div>
        </div>
      </div>
      <div class="header_bottom">
        <div class="container-fluid">
          <nav class="navbar navbar-expand-lg custom_nav-container">
            <a class="navbar-brand" href="#">
              <span>
                Shupavu Startup
              </span>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class=""></span>
            </button>
  <?php
if (isset($_SESSION['username'])) {
?>
            <div class="collapse navbar-collapse ml-auto" id="navbarSupportedContent">
              <ul class="navbar-nav  ">
                <li class="nav-item active">
                  <a class="nav-link" href="index3.php">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index3.php"> Database Records</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index3.php"> My Module </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="logout.php">Logout</a>
                </li>
              </ul>
            </div>
        <?php
    }else{
        ?>
            <div class="collapse navbar-collapse ml-auto" id="navbarSupportedContent">
              <ul class="navbar-nav  ">
                <li class="nav-item active">
                  <a class="nav-link" href="index1.php">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index1.php"> Database Records</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index1.php"> My Module </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="logout.php">Logout</a>
                </li>
              </ul>
            </div>
        <?php
    }
    ?>
          </nav>
        </div>
      </div>
    </header>
    <!-- end header section -->
    <!-- slider section -->
    <section class=" slider_section ">
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="container">
              <div class="row">
                <div class="col-md-7">
                  <div class="detail-box">
                    <h1>
                      Welcome <?php echo $row1['User_Type']; ?>,  <br>
                      <span>
                        <?php echo $row1['Fullname']; ?>!
                      </span>
                    </h1>
                    <p>
                      Access resources, mentorship, and funding to take your startup to new heights.
                    </p>
                    <div class="btn-box">
                      <a href="#data" class="btn-1"> Database Records </a>
                      <a href="#mod" class="btn-2">My Module</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item ">
            <div class="container">
              <div class="row">
                <div class="col-md-7">
                  <div class="detail-box">
                    <h1>
                      Welcome <?php echo $row1['User_Type']; ?>,  <br>
                      <span>
                        <?php echo $row1['Fullname']; ?>!
                      </span>
                    </h1>
                    <p>
                      Where creativity meets opportunity – join Shupavu Startup today and be part of Kenya's innovation revolution.
                    </p>
                    <div class="btn-box">
                      <a href="#data" class="btn-1"> Database Records </a>
                      <a href="#mod" class="btn-2">My Module</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item ">
            <div class="container">
              <div class="row">
                <div class="col-md-7">
                  <div class="detail-box">
                    <h1>
                      Welcome <?php echo $row1['User_Type']; ?>,  <br>
                      <span>
                        <?php echo $row1['Fullname']; ?>!
                      </span>
                    </h1>
                    <p>
                       Expand your network, forge meaningful connections, and collaborate with fellow entrepreneurs on Shupavu Startup.
                    </p>
                    <div class="btn-box">
                      <a href="#data" class="btn-1"> Database Records </a>
                      <a href="#mod" class="btn-2">My Module</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="container idicator_container">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
        </div>
      </div>
    </section>
    <!-- end slider section -->
  </div>

  <!-- my module section -->

  <section id="mod" class="contact_section layout_padding">
    <div class="contact_bg_box">
      <div class="img-box">
        <img src="images/contact-bg.jpg" alt="">
      </div>
    </div>
    <div class="container">
      <div class="heading_container heading_center">
        <h2>
          Messaging Platform
        </h2>
      </div>
      <div class="">
        <div class="row">
          <div class="col-md-12 mx-auto">

            <div class="Ccontainer">
                <div class="row align-items-center">
                                        <div class="col-lg-12" style="text-align: center;">
                        <div class="volunteer-content">
                            <div class="section-header">
                                <p style="color: black;">Chat with <?php echo $filter2; ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12" style="overflow:auto;">
                      <div class="Ccontainer" id="replySection">
<?php
$sql = "SELECT * FROM `chat` WHERE `Sender` = '$filter1' OR `Receiver` = '$filter1'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
if ($row['Sender'] != $filter1) {
?>
  <h5 style="color: black;"><?php echo($row["Sender"]); ?></h5>
  <p style="color: black;"><?php echo($row["Message"]); ?></p>
  <span class="time-right"><?php echo($row["Created_At"]); ?></span>
  <br>
  <br>
</div>
<?php
}else{
?>
<div class="Ccontainer darker">
  <h5 style="color: black;"><?php echo($row["Sender"]); ?></h5>
  <p style="color: black;"><?php echo($row["Message"]); ?></p>
  <span class="time-right"><?php echo($row["Created_At"]); ?></span>
  <form action="insertion.inc.php" method="POST">
    <input type="hidden" value="<?php echo($row["Chat_ID"]); ?>" name="cid">
  <span class="time-left"><button class="btn btn-custom" name="deleteCh">Delete</button></span>    
  </form>

  <br>
  <br>
</div>
<?php
}
}
}else{
  echo "No messages sent yet...";
}               
?>
     </div>
                    <div class="col-lg-12">
                        <form method="POST" action="insertion.inc.php">
                            <div class="contact_form-container">
                            <div>
                  <div class="">
                    <input type="text" placeholder="Message..." class="message_input" required name="desc" />
                  </div>
                  <div class="btn-box ">
                    <button type="submit" name="addCh">
                      Send Message
                    </button>
                  </div>
              </div>
          </div>
                            </form>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end my module section -->

  <!-- info section -->
  <section id="contact" class="info_section ">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="info_logo">
            <a class="navbar-brand" href="#">
              <span>
                Our Mission
              </span>
            </a>
            <p>
             From idea to execution, Shupavu Startup is here to support you at every step of your entrepreneurial journey.
            </p>
          </div>
        </div>
        <div class="col-md-16">
          <div class="info_info">
            <h5>
              Contact Us
            </h5>
          </div>
          <div class="info_contact">
            <a href="" class="">
              <i class="fa fa-map-marker" aria-hidden="true"></i>
              <span>
               Location : Nairobi, Kenya,
              </span>
            </a>
            <a href="" class="">
              <i class="fa fa-phone" aria-hidden="true"></i>
              <span>
                Call : +254 712345678
              </span>
            </a>
            <a href="" class="">
              <i class="fa fa-envelope" aria-hidden="true"></i>
              <span>
                Email Address : info@shupavu.org
              </span>
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end info_section -->




  <!-- footer section -->
  <footer class="container-fluid footer_section">
    <p>
      &copy; <span id="currentYear"></span> All Rights Reserved.
    </p>
  </footer>
  <!-- footer section -->

  <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="js/custom.js"></script>
</body>

</html>