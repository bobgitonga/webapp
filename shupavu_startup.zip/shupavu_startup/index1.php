<?php
require_once 'dbconnection.inc.php';
session_start();

if (!isset($_SESSION['menname']) && !isset($_SESSION['menname1'])) {
    header("Location: index.html");
}else{
  $filter = $_SESSION['menname'];
  $query=mysqli_query($conn,"SELECT * FROM `users` WHERE `User_ID`='$filter'")or die(mysqli_error());
  $row1=mysqli_fetch_array($query);
  $filter1 = $row1['Fullname'];
}
?>

<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>Shupavu Startup - Mentor Homepage</title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,600,700&display=swap" rel="stylesheet" />

  <!-- Custom styles -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>
        <style type="text/css">
        
          table{
    align-items: center;
  }

   th, tr, td{
    padding: 10px 10px;
  }
    </style>

            <script type="text/javascript">
function printData()
{
   var divToPrint=document.getElementById("printTable");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
}

$('button').on('click',function(){
printData();
})  
</script>
<body>
  <div class="hero_area">
    <!-- header section strats -->
    <div class="hero_bg_box">
      <div class="img-box">
        <img src="images/hero-bg.jpg" alt="">
      </div>
    </div>

    <header class="header_section">
      <div class="header_top">
        <div class="container-fluid">
          <div class="contact_link-container">
            <a href="" class="contact_link1">
              <i class="fa fa-map-marker" aria-hidden="true"></i>
              <span>
                Location : Nairobi, Kenya,
              </span>
            </a>
            <a href="" class="contact_link2">
              <i class="fa fa-phone" aria-hidden="true"></i>
              <span>
                Call : +254 712345678
              </span>
            </a>
            <a href="" class="contact_link3">
              <i class="fa fa-envelope" aria-hidden="true"></i>
              <span>
                Email Address : info@shupavu.org
              </span>
            </a>
          </div>
        </div>
      </div>
      <div class="header_bottom">
        <div class="container-fluid">
          <nav class="navbar navbar-expand-lg custom_nav-container">
            <a class="navbar-brand" href="#">
              <span>
                Shupavu Startup
              </span>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class=""></span>
            </button>

            <div class="collapse navbar-collapse ml-auto" id="navbarSupportedContent">
              <ul class="navbar-nav  ">
                <li class="nav-item active">
                  <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#data"> Database Records</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#mod"> My Module </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="logout.php">Logout</a>
                </li>
              </ul>
            </div>
          </nav>
        </div>
      </div>
    </header>
    <!-- end header section -->
    <!-- slider section -->
    <section class=" slider_section ">
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="container">
              <div class="row">
                <div class="col-md-7">
                  <div class="detail-box">
                    <h1>
                      Welcome <?php echo $row1['User_Type']; ?>,  <br>
                      <span>
                        <?php echo $row1['Fullname']; ?>!
                      </span>
                    </h1>
                    <p>
                      Access resources, mentorship, and funding to take your startup to new heights.
                    </p>
                    <div class="btn-box">
                      <a href="#data" class="btn-1"> Database Records </a>
                      <a href="#mod" class="btn-2">My Module</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item ">
            <div class="container">
              <div class="row">
                <div class="col-md-7">
                  <div class="detail-box">
                    <h1>
                      Welcome <?php echo $row1['User_Type']; ?>,  <br>
                      <span>
                        <?php echo $row1['Fullname']; ?>!
                      </span>
                    </h1>
                    <p>
                      Where creativity meets opportunity – join Shupavu Startup today and be part of Kenya's innovation revolution.
                    </p>
                    <div class="btn-box">
                      <a href="#data" class="btn-1"> Database Records </a>
                      <a href="#mod" class="btn-2">My Module</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item ">
            <div class="container">
              <div class="row">
                <div class="col-md-7">
                  <div class="detail-box">
                    <h1>
                      Welcome <?php echo $row1['User_Type']; ?>,  <br>
                      <span>
                        <?php echo $row1['Fullname']; ?>!
                      </span>
                    </h1>
                    <p>
                       Expand your network, forge meaningful connections, and collaborate with fellow entrepreneurs on Shupavu Startup.
                    </p>
                    <div class="btn-box">
                      <a href="#data" class="btn-1"> Database Records </a>
                      <a href="#mod" class="btn-2">My Module</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="container idicator_container">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
        </div>
      </div>
    </section>
    <!-- end slider section -->
  </div>

  <!-- database records section -->

  <section id="about" class="about_section layout_padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 px-0">
          <div class="detail-box">
            <div class="heading_container ">
              <h2>
                View Database Records
              </h2>
              <br>
              <h3>List of Job Openings</h3>
            </div>
<table id="printTable">
<tr style="text-align: left;
  padding: 8px;">
<th style="text-align: left;
  padding: 8px;">Job Opening ID</th>
  <th style="text-align: left;
  padding: 8px;">Applicant Details</th>
<th style="text-align: left;
  padding: 8px;">Name</th>
  <th style="text-align: left;
  padding: 8px;">Description</th>
 <th style="text-align: left;
  padding: 8px;">Fee (in kshs.)</th>
  <th style="text-align: left;
  padding: 8px;">Picture</th>
 <th style="text-align: left;
  padding: 8px;">Status</th>
   <th style="text-align: left; padding: 8px;"></th>
   <th style="text-align: left; padding: 8px;"></th>
</tr>

<?php

$sql = "SELECT `applications`.*, `users`.* FROM `applications` JOIN `users` ON `users`.`User_ID` = `applications`.`Mentee_ID` WHERE `applications`.`Mentor_ID` = '$filter'";
$sql1 = "SELECT COUNT(`Chat_ID`) AS `NR` FROM `chat` WHERE `Receiver` = '$filter1' AND `Status` = 'Delivered'";
$result = $conn->query($sql);
$result1 = $conn->query($sql1);
if (($result->num_rows > 0) && ($result1->num_rows > 0)){
// output data of each row
while (($row = $result->fetch_assoc()) && ($row3 = $result1->fetch_assoc())) {
?>
<tr>
<td><?php echo($row["Application_ID"]); ?></td>
<?php
if (($row['Mentee_ID'] == "") || ($row['Mentee_ID'] == "1")) {
?>
<td></td>
<?php
}else{
?>
<td><?php echo($row["Fullname"]); ?> reach out on <?php echo($row["Phone_Number"]); ?> & <?php echo($row["Email_Address"]); ?></td>
<?php
}
?>
<td><?php echo($row["Name"]); ?></td>
<td><?php echo($row["Description"]); ?></td>
<td><?php echo($row["Fee"]); ?> kshs.</td>
<td><img src="images/<?php echo($row["Image"]); ?>" style="width: 150px;" alt></td>
<td><?php echo($row["Status"]); ?></td>
<?php
if($row["Status"] != "Active"){
?>
<td><button class="btn btn-primary py-3 px-5" onclick="return confirm('Are you sure that you want to activate this application?')?window.location.href='insertion.inc.php?action=activateA&id=<?php echo($row["Application_ID"]); ?>':true;" title='Activate Application'>Activate</button></td>
<?php
}else{
?>
<td><button class="btn btn-primary py-3 px-5" onclick="return confirm('Are you sure that you want to deactivate this application?')?window.location.href='insertion.inc.php?action=deactivateA&id=<?php echo($row["Application_ID"]); ?>':true;" title='Deactivate Application'>Deactivate</button></td>
<?php
}
?>
<?php
if ($row['Mentee_ID'] != "") {
?>
<td><button class="btn btn-primary py-3 px-5" onclick="return confirm('Are you sure that you want to message this mentee?')?window.location.href='insertion.inc.php?action=viewC&id=<?php echo($row["Fullname"]); ?>':true;" title='View Chat'>Message Mentee
<?php
$nr = $row3["NR"];
if ($nr != 0) {
?>
(<?php echo($row3["NR"]); ?>)
</button></td>
<?
}else{
?>
<?php
}
}else{
?>
<td></td>
<?php
}
?>
</tr>
<?php
}
} else { echo "No results"; }

?>

</table>
            <div class="btn-box">
              <a onclick="printData();">
                Print
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end database records section -->

  <!-- my module section -->

  <section id="mod" class="contact_section layout_padding">
    <div class="contact_bg_box">
      <div class="img-box">
        <img src="images/contact-bg.jpg" alt="">
      </div>
    </div>
    <div class="container">
      <div class="heading_container heading_center">
        <h2>
          My Module
        </h2>
      </div>
      <div class="">
        <div class="row">
          <div class="col-md-6 mx-auto">
            <form action="insertion.inc.php" method="POST" enctype="multipart/form-data">
              <div class="contact_form-container">
                <div>
                  <div>
                    <input type="text" placeholder="Application Name" required name="aname" />
                  </div>
                  <div>
                    <input type="number" min="0" placeholder="Fee(s) Amount" name="fee" required />
                  </div>
                  <div>
                    <label>Date Due:</label>
                    <br>
                    <input type="date" min="<?php echo date('Y-m-d'); ?>"  name="end" required />
                  </div>
                  <div>
                    <label>Picture of Application:</label>
                    <br>
                    <input type="file" accept=".jpg, .png, .jpeg" name="image" required />
                  </div>
                  <div class="">
                    <input type="text" placeholder="Description..." class="message_input" required name="desc" />
                  </div>
                  <div class="btn-box ">
                    <button type="submit" name="addA">
                      Add Application
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
                    <div class="col-md-6 mx-auto">
            <form action="insertion.inc.php" method="POST" enctype="multipart/form-data">
              <div class="contact_form-container">
                <div>
                  <div>
                      <select name="uid" required>
                          <option value="" disabled selected>Kindly Select A User</option>
                                     <?php
                                      $sql = "SELECT * FROM `users` WHERE `User_Type` = 'User'";
                                      $all_categories = mysqli_query($conn,$sql);
                                      while ($category = mysqli_fetch_array(
                                              $all_categories,MYSQLI_ASSOC)):;
                                  ?>
                                  <option value="<?php echo $category["User_ID"];?>"><?php echo $category["Fullname"];?></option>
                                  <?php
                                      endwhile;
                                  ?>
                      </select>
                      <br>
                  </div>
                  <div>
                      <select name="did" required>
                          <option value="" disabled selected>Kindly Select An Application</option>
                                     <?php
                                      $sql = "SELECT * FROM `applications` WHERE `Mentor_ID` = '$filter'";
                                      $all_categories = mysqli_query($conn,$sql);
                                      while ($category = mysqli_fetch_array(
                                              $all_categories,MYSQLI_ASSOC)):;
                                  ?>
                                  <option value="<?php echo $category["Application_ID"];?>"><?php echo $category["Name"];?></option>
                                  <?php
                                      endwhile;
                                  ?>
                      </select>
                      <br>
                  </div>
                  <div class="btn-box ">
                    <button type="submit" name="completeA">
                      Complete Application
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
                    <div class="col-md-12 mx-auto">
            <form action="insertion.inc.php" method="POST">
              <div class="contact_form-container">
                <div>
                <div>
                    <input type="text" placeholder="Full Name (Letters Only)" value="<?php echo $row1['Fullname']; ?>" required name="fname" pattern="[A-Za-z\s]+"/>
                    <input type="hidden" value="2" required name="mod">
                    <input type="hidden" value="<?php echo $filter; ?>" required name="uid">
                  </div>
                  <div>
                    <input type="email" placeholder="Email Address" value="<?php echo $row1['Email_Address']; ?>" name="email" required />
                  </div>
                  <div>
                    <input type="text" placeholder="Phone Number (Numbers Only)" value="<?php echo $row1['Phone_Number']; ?>" name="phone" required pattern="[0-9]{10}"/>
                  </div>
                  <div>
                    <input type="password" placeholder="Password" name="password" required />
                  </div>
                  <div>
                    <input type="password" placeholder="Confirm Password" name="cpassword" required />
                  </div>
                  <div class="btn-box ">
                    <button type="submit" name="upu">
                      Update My Details
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end my module section -->

  <!-- info section -->
  <section id="contact" class="info_section ">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="info_logo">
            <a class="navbar-brand" href="#">
              <span>
                Our Mission
              </span>
            </a>
            <p>
             From idea to execution, Shupavu Startup is here to support you at every step of your entrepreneurial journey.
            </p>
          </div>
        </div>
        <div class="col-md-16">
          <div class="info_info">
            <h5>
              Contact Us
            </h5>
          </div>
          <div class="info_contact">
            <a href="" class="">
              <i class="fa fa-map-marker" aria-hidden="true"></i>
              <span>
               Location : Nairobi, Kenya,
              </span>
            </a>
            <a href="" class="">
              <i class="fa fa-phone" aria-hidden="true"></i>
              <span>
                Call : +254 712345678
              </span>
            </a>
            <a href="" class="">
              <i class="fa fa-envelope" aria-hidden="true"></i>
              <span>
                Email Address : info@shupavu.org
              </span>
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end info_section -->




  <!-- footer section -->
  <footer class="container-fluid footer_section">
    <p>
      &copy; <span id="currentYear"></span> All Rights Reserved.
    </p>
  </footer>
  <!-- footer section -->

  <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="js/custom.js"></script>
</body>

</html>