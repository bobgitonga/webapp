<?php
require_once "dbconnection.inc.php";

session_start();

session_destroy();

if(isset($_POST['login'])){

    $id = $_POST['email'];
    $password = $_POST['password'];   

         $sql = "SELECT * FROM `users` WHERE `Email_Address`='$id'";

        $query = mysqli_query($conn,$sql);

        if(mysqli_num_rows($query) > 0){
            $row = mysqli_fetch_assoc($query);

            $pass = $row['Password'];
            $type = $row['User_Type'];

if(md5($password) == $pass){

                session_start();

                if ($type == "Administrator") {
                $_SESSION['adminname'] = $row['User_ID'];
                header("Location: index.php");
                }else if ($type == "Mentor") {
                $_SESSION['menname'] = $row['User_ID'];
                $_SESSION['menname1'] = $row['Fullname'];                
                header("Location: index1.php");
                }else if ($type == "Content Provider") {
                $_SESSION['contpname'] = $row['User_ID'];
                header("Location: index2.php");
                }else if ($type == "User") {
                $_SESSION['username'] = $row['User_ID'];
                $_SESSION['username1'] = $row['Fullname'];                
                header("Location: index3.php");
                }
            }else{
                echo "Incorrect Password.";
            }
        }else{
            echo "User does not exist.";
        }
}
           
?>
